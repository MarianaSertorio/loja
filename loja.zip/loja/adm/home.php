<?php
session_start();
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://getbootstrap.com/docs/5.2/assets/css/docs.css" rel="stylesheet">
    <link href="galeria.css" rel="stylesheet">
    <title>Bootstrap Example</title>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body class="p-3 m-0 border-0 bd-example">
<?php
		if(isset($_SESSION['msg'])){
			echo $_SESSION['msg'];
			unset($_SESSION['msg']);
		}
		?>
    <!-- Example Code -->

    <nav class="navbar navbar-expand-lg bg-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">MAKE</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="home.html">HOME</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">CATALOGO</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="cadastro.html">ENTRAR</a>
                    </li>
                </ul>
                <form class="d-flex" role="search">
                    <input class="form-control me-2" type="search" aria-label="Search">
                    <button class="btn btn-outline-success" type="submit">pesquisar</button>
                </form>
            </div>
        </div>
    </nav>
    <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="imagens/make.jpg" class="d-block w-100" alt="..." height="800">
            </div>
            <div class="carousel-item">
                <img src="imagens/make1.jpg" class="d-block w-100" alt="..." height="800">
            </div>
            <div class="carousel-item">
                <img src="imagens/make2.jpg" class="d-block w-100" alt="..." height="800">
            </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls"
            data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls"
            data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>
    <br><br><br> <br><br><br>

    <main>
        <div class="gallery-container">
            <a href="#chick-hicks" class="gallery-items">
                <img src="imagens/catalogo.jpg" alt="Chick Hicks">
            </a>
            <a href="imagens/catalogo.jpg" class="gallery-items">
                <img src="imagens/catalogo.jpg" alt="Doctor Hudson">
            </a>
            <a href="imagens/catalogo.jpg" class="gallery-items">
                <img src="imagens/catalogo.jpg" alt="Fillmore">
            </a>
            <a href="imagens/catalogo1.jpg" class="gallery-items">
                <img src="imagens/catalogo1.jpg" alt="Flo">
            </a>
            <a href="imagens/catalogo1.jpg" class="gallery-items">
                <img src="imagens/catalogo1.jpg" alt="Guido">
            </a>
            <a href="imagens/catalogo1.jpg" class="gallery-items">
                <img src="imagens/catalogo1.jpg" alt="lightning-mcqueen">
            </a>
            <a href="imagens/catalogo2.jpg" class="gallery-items">
                <img src="imagens/catalogo2.jpg" alt="Lizzie">
            </a>
            <a href="imagens/catalogo2.jpg" class="gallery-items">
                <img src="imagens/catalogo2.jpg" alt="Luigi">
            </a>
            <a href="imagens/catalogo2.jpg" class="gallery-items">
                <img src="imagens/catalogo2.jpg" alt="Mack">
            </a>
        </div>        
    </main>


    <!-- End Example Code -->
</body>

</html>