<div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="imagens/make.jpg" class="d-block w-100" alt="..." height="800">
            </div>
            <div class="carousel-item">
                <img src="imagens/make1.jpg" class="d-block w-100" alt="..." height="800">
            </div>
            <div class="carousel-item">
                <img src="imagens/make2.jpg" class="d-block w-100" alt="..." height="800">
            </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls"
            data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls"
            data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>
    <br><br><br> <br><br><br>

    <main>
        <div class="gallery-container">
            <a href="#chick-hicks" class="gallery-items">
                <img src="imagens/catalogo.jpg" alt="Chick Hicks">
            </a>
            <a href="imagens/catalogo.jpg" class="gallery-items">
                <img src="imagens/catalogo.jpg" alt="Doctor Hudson">
            </a>
            <a href="imagens/catalogo.jpg" class="gallery-items">
                <img src="imagens/catalogo.jpg" alt="Fillmore">
            </a>
            <a href="imagens/catalogo1.jpg" class="gallery-items">
                <img src="imagens/catalogo1.jpg" alt="Flo">
            </a>
            <a href="imagens/catalogo1.jpg" class="gallery-items">
                <img src="imagens/catalogo1.jpg" alt="Guido">
            </a>
            <a href="imagens/catalogo1.jpg" class="gallery-items">
                <img src="imagens/catalogo1.jpg" alt="lightning-mcqueen">
            </a>
            <a href="imagens/catalogo2.jpg" class="gallery-items">
                <img src="imagens/catalogo2.jpg" alt="Lizzie">
            </a>
            <a href="imagens/catalogo2.jpg" class="gallery-items">
                <img src="imagens/catalogo2.jpg" alt="Luigi">
            </a>
            <a href="imagens/catalogo2.jpg" class="gallery-items">
                <img src="imagens/catalogo2.jpg" alt="Mack">
            </a>
        </div>        
    </main>